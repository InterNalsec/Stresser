<?php 

session_start();
$page = "Dashboard";
include 'header.php';
?>


<div class="wrapper">
  <div class="container-fluid">
    <div class="page-title-box">
      <div class="row align-items-center">
        <div class="col-sm-12">
            <ol class="breadcrumb">
                <li class="breadcrumb-item active">Oblivion / Dashboard</li>
            </ol>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-xl-3 col-md-6">
          <div class="card mini-stat bg-primary text-white">
              <div class="card-body">
                  <div class="mb-4">
                      <div class="float-left mini-stat-img mr-4">
                          <img src="assets/images/services-icon/01.png" alt="" >
                      </div>
                      <h5 class="font-16 text-uppercase mt-0 text-white-50">Total Atacks</h5>
                      <h4 class="font-500"><?php echo $TotalAttacks; ?> <i class="mdi mdi-arrow-up text-success ml-2"></i></h4>
                  </div>
                  <div class="pt-2">
                  </div>
              </div>
          </div>
      </div>
      <div class="col-xl-3 col-md-6">
          <div class="card mini-stat bg-primary text-white">
              <div class="card-body">
                  <div class="mb-4">
                      <div class="float-left mini-stat-img mr-4">
                          <img src="assets/images/services-icon/01.png" alt="" >
                      </div>
                      <h5 class="font-16 text-uppercase mt-0 text-white-50">Total Servers</h5>
                      <h4 class="font-500"><?php echo $TotalPools; ?> <i class="mdi mdi-arrow-up text-success ml-2"></i></h4>
                  </div>
                  <div class="pt-2">
                  </div>
              </div>
          </div>
      </div>
      <div class="col-xl-3 col-md-6">
        <div class="card mini-stat bg-primary text-white">
            <div class="card-body">
                <div class="mb-4">
                    <div class="float-left mini-stat-img mr-4">
                        <img src="assets/images/services-icon/01.png" alt="" >
                    </div>
                    <h5 class="font-16 text-uppercase mt-0 text-white-50">Running Attacks</h5>
                    <h4 class="font-500"><?php echo $RunningAttacks; ?> <i class="mdi mdi-arrow-up text-success ml-2"></i></h4>
                </div>
                <div class="pt-2">
                    
                </div>
            </div>
        </div>
      </div>
      <div class="col-xl-3 col-md-6">
          <div class="card mini-stat bg-primary text-white">
              <div class="card-body">
                  <div class="mb-4">
                      <div class="float-left mini-stat-img mr-4">
                          <img src="assets/images/services-icon/01.png" alt="" >
                      </div>
                      <h5 class="font-16 text-uppercase mt-0 text-white-50">Total Users</h5>
                      <h4 class="font-500"><?php echo $TotalUsers; ?> <i class="mdi mdi-arrow-up text-success ml-2"></i></h4>
                  </div>
                  <div class="pt-2">
                      
                  </div>
              </div>
          </div>
      </div>
    </div>
    <div class="row">
      <div class="col-xl-4">
        <div class="card">
            <div class="card-body">
                <h4 class="mt-0 header-title mb-4">Latest News</h4>
                <ol class="activity-feed mb-0">
                  <?php 
                  $SQLGetNews = $odb -> query("SELECT * FROM `news` ORDER BY `date` DESC LIMIT 4");
                  while ($getInfo = $SQLGetNews -> fetch(PDO::FETCH_ASSOC)){
                    $date = date("m-d-Y, h:i:s a" ,$getInfo['date']);
                    $title = $getInfo['title'];
                    $content = $getInfo['content'];

                  ?>
                    <li class="feed-item">
                        <div class="feed-item-list">
                            <span class="date"><?=$date?></span>
                            <span class="activity-text"><b><?=$title?></b></span>
                            <p class="activity-text" style="font-weight: light"><?=$content?></p>

                        </div>
                    </li>
                  <?php } ?>
                </ol>
            </div>
        </div>
      </div>
      <div class="col-xl-8">
        <div class="card">
          <div class="card-body">
            <h4 class="mt-0 header-title mb-4">Attacks Graph</h4>
            <div>
              <div id="chart-attacks" class="ct-chart earning ct-golden-section"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12">
          <div class="card">
              <div class="card-body">
                  <h4 class="mt-0 header-title mb-4"> Best 8 Methods</h4>
                  <div class="table-responsive">
                      <table class="table table-hover">
                          <thead>
                              <tr>
                              <th scope="col">METHOD</th>
                              <th scope="col">ATTACKS</th>
                              <th scope="col">DATE</th>
                              <th scope="col">PERCENT</th>
                              <th scope="col" colspan="2">NETWORK</th>
                              </tr>
                          </thead>
                          <tbody>
                            
                        <?php
                      
                        $SQLGetMethods = $odb -> query("SELECT * FROM `logs`");
                        $metodos_limit = 0;
                        while($getInfo = $SQLGetMethods -> fetch(PDO::FETCH_ASSOC)){
                          if (!(isset($Metodos[$getInfo['method']]))) {
                          $Metodos[$getInfo['method']] = 0;
                          }
                          $Metodos[$getInfo['method']] = $Metodos[$getInfo['method']] + 1;
                        }
                        asort($Metodos);
                        $Metodos = array_reverse($Metodos);
                        $Metodos = array_slice($Metodos, 0, 8, true);

                        $Total = 0;


                        foreach ($Metodos as $key => $value) {
                          $Total = $Total + $value;
                        }

                        function get_percentage($total, $number)
                        {
                          if ( $total > 0 ) {
                            return round($number / ($total / 100),2);
                          } else {
                            return 0;
                          }
                        }



                        foreach ($Metodos as $key => $value) {
                          $Porcentaje = get_percentage($Total, $value);
                      
                        if ($Porcentaje >= 0 and $Porcentaje <= 10 )
                      {
                  $ripx = '<div class="progress progress-lg m-b-5" style="margin-bottom:0px;"><div class="progress-bar bg-success" role="progressbar" aria-valuenow="'. $Porcentaje .'" aria-valuemin="0" aria-valuemax="100" style="width:'. $Porcentaje .'%; visibility: visible; animation-name: animationProgress;"><center>' . $Porcentaje . '%</center></div></div>';
                      }elseif ($Porcentaje >= 11 and $Porcentaje <= 25 )
                      {
                  $ripx = '<div class="progress progress-lg m-b-5" style="margin-bottom:0px;"><div class="progress-bar bg-info" role="progressbar" aria-valuenow="'. $Porcentaje .'" aria-valuemin="0" aria-valuemax="100" style="width: '. $Porcentaje .'%; visibility: visible; animation-name: animationProgress;"><center>' . $Porcentaje . '%</center></div></div>';
                      }elseif ($Porcentaje >= 25 and $Porcentaje <= 30 )
                      {
                  $ripx = '<div class="progress progress-lg m-b-5" style="margin-bottom:0px;"><div class="progress-bar bg-warning" role="progressbar" aria-valuenow="'. $Porcentaje .'" aria-valuemin="0" aria-valuemax="100" style="width: '. $Porcentaje .'%; visibility: visible; animation-name: animationProgress;"><center>' . $Porcentaje . '%</center></div></div>';
                      }elseif ($Porcentaje >= 40 and $Porcentaje <= 100 )
                      {
                  $ripx = '<div class="progress progress-lg m-b-5" style="margin-bottom:0px;"><div class="progress-bar bg-danger" role="progressbar" aria-valuenow="'. $Porcentaje .'" aria-valuemin="0" aria-valuemax="100" style="width: '. $Porcentaje .'%; visibility: visible; animation-name: animationProgress;"><center>' . $Porcentaje . '%</center></div></div>';
                      }
                      ?>
                            <tr>
                              <th scope="row"><?=htmlspecialchars($key)?></th>
                              <td>
                                  <?=$value?>
                              </td>
                              <td>15/01/2019</td>
                              <td>
                               <?=$ripx?>
                              </td>
                              <td>All Network</td>
                            </tr>
                            <?php } ?>
                          </tbody>
                      </table>
                  </div>
              </div>
          </div>
      </div>
    </div>
  </div>
</div>
<?php
include 'footer.php';
?>

