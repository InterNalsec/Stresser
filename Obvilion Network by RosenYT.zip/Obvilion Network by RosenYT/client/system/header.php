 <?php 
 
	     if(basename($_SERVER['SCRIPT_FILENAME']) == basename(__FILE__)) 
	     die("Access denied bitch");
	
	     ob_start();
	
	     require_once '../rip/configuration.php';
	     require_once '../rip/init.php';

          $ip = $_SERVER['REMOTE_ADDR'];
          
 
         $checksession = $odb->prepare("SELECT * FROM users WHERE id = ?");
         $checksession->execute(array($_SESSION['ID']));
         while($session = $checksession->fetch(PDO::FETCH_ASSOC)){
         $lastsession = $session['lastact'];
         $dif = time() - $lastsession; 
         if($dif < 7200){
         }
         else
         {
         header('location: login.php?session=rip');
		 session_destroy();
         die();
         }
         }

		 if (!($user->isAdmin($odb)))
          {
           header('location: ../logout.php');
            die();
           }

         if (!($user -> LoggedIn()) || !($user -> notBanned($odb))){
		 header('location: logout.php');
		 die();
	      } 
          $update = $odb->prepare("UPDATE users SET lastact = ? WHERE ID = ?");
          $update->execute(array(time(), $_SESSION['ID']));
?>
<!doctype html>
<html lang="en" class="no-focus"><!--<![endif]--><head>
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
        <title>Oblivion | Admin</title>
        <meta content="Oblivion Admin" name="description" />
        <meta content="Themesbrand" name="author" />
        <link rel="shortcut icon" href="assets/images/favicon.ico">

        <!--Chartist Chart CSS -->
        <link rel="stylesheet" href="../plugins/chartist/css/chartist.min.css">
        <link href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css">

        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css">

        <link href="assets/css/style.css" rel="stylesheet" type="text/css">

        
    </head>
<body class="" style="">
   <!-- Navigation Bar-->
   <header id="topnav">
            <div class="topbar-main">
                <div class="container-fluid">

                    <!-- Logo container-->
                    <div class="logo">
                        
                        <a href="home.php" class="logo">
                            <h2>Oblivion Admin</h2>
                        </a>

                    </div>

                    <!-- End Logo container-->


                    <div class="menu-extras topbar-custom">

                        <ul class="navbar-right list-inline float-right mb-0">
                           
                            <li class="dropdown notification-list list-inline-item">
                                <div class="dropdown notification-list nav-pro-img">
                                    <a class="dropdown-toggle nav-link arrow-none nav-user" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                        <img src="assets/images/users/user-4.jpg" alt="user" class="rounded-circle">
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                                        <!-- item-->
                                        <a class="dropdown-item" href="../profile.php"><i class="mdi mdi-account-circle m-r-5"></i> Profile</a>
    
                                        <a class="dropdown-item text-danger" href="../logout.php"><i class="mdi mdi-power text-danger" ></i> Logout</a>
                                    </div>
                                </div>
                            </li>    
                            
                            <li class="menu-item list-inline-item">
                                <!-- Mobile menu toggle-->
                                <a class="navbar-toggle nav-link">
                                    <div class="lines">
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                    </div>
                                </a>
                                <!-- End mobile menu toggle-->
                            </li>

                        </ul>
                    </div>
                    <!-- end menu-extras -->

                    <div class="clearfix"></div>

                </div> <!-- end container -->
            </div>
            <!-- end topbar-main -->

            <!-- MENU Start -->
            <div class="navbar-custom">
                <div class="container-fluid">
                    <div id="navigation">
                        <!-- Navigation Menu-->
                        <ul class="navigation-menu">

                            <li class="has-submenu">
                                <a href="home.php"><i class="fas fa-home"></i>Home</a>
                            </li>
                            <li class="has-submenu">
                                <a href="apix.php"><i class="fas fa-bolt"></i>API</a>
                            </li><li class="has-submenu">
                                <a href="plans.php"><i class="fas fa-users"></i>Plans</a>
                            </li><li class="has-submenu">
                                <a href="liveattacks.php"><i class="fas fa-cog"></i>Live Attacks</a>
                            </li><li class="has-submenu">
                                <a href="blacklist.php"><i class="fas fa-ban"></i>Blacklist</a>
                            </li><li class="has-submenu">
                                <a href="attacklogs.php"><i class="fas fa-location-arrow"></i>Attacks Logs</a>
                            </li><li class="has-submenu">
                                <a href="loginlogs.php"><i class="fas fa-key"></i>Login Logs</a>
                            </li><li class="has-submenu">
                                <a href="news.php"><i class="fas fa-newspaper"></i>News</a>
                            </li><li class="has-submenu">
                                <a href="members.php"><i class="fas fa-users"></i>Member</a>
                            </li><li class="has-submenu">
                                <a href="../hub.php"><i class="fas fa-fast-backward"></i>Return</a>
                            </li>
                        </ul>
                        <!-- End navigation menu -->
                    </div> <!-- end #navigation -->
                </div> <!-- end container -->
            </div> <!-- end navbar-custom -->
        </header>
        <!-- End Navigation Bar-->
<script>
				    window.setInterval(function(){
					var xmlhttp;
					if (window.XMLHttpRequest){
				    xmlhttp = new XMLHttpRequest();
					}
					else{
				    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
					}
					xmlhttp.open("GET","../includes/check.php",true);
					xmlhttp.send(); 
					}, 5000);
          function logOut() {
              swal({
                  buttonsStyling: !1,
                  confirmButtonClass: "btn btn-lg btn-alt-success m-5",
                  cancelButtonClass: "btn btn-lg btn-alt-danger m-5",
                  inputClass: "form-control",
                  title: "Are you sure?",
                  text: "Are you sure you want to end the session?",
                  type: "warning",
                  showCancelButton: !0,
                  confirmButtonColor: "#d26a5c",
                  confirmButtonText: "Yes, Logout!",
                  html: !1,
                  preConfirm: function() {
                      return new Promise(function(n) {
                          setTimeout(function() {
                              n()
                          }, 50)
                      })
                  }
              }).then(function(n) {
                  setTimeout(function() {
                      window.location.replace('logout.php');
                  }, 3000)
                  swal("Bye Bye!", "Youv'e just being redirected to the login page...", "success")
              }, function(n) {})

          }
</script>

<div class="wrapper" style="margin-top: 50px">
            <div class="container-fluid">