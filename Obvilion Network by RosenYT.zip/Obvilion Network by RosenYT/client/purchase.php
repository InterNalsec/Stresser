<?php 

	
session_start();
$page = "Purchase";
include 'header.php';
    $runningrip = $odb->query("SELECT COUNT(*) FROM `logs` WHERE `time` + `date` > UNIX_TIMESTAMP() AND `stopped` = 0")->fetchColumn(0);
	$slotsx = $odb->query("SELECT COUNT(*) FROM `api` WHERE `slots`")->fetchColumn(0);
	$load    = round($runningrip / $slotsx * 100, 2);	


if(isset($_POST['x'])){
    $DisApi = 'https://www.oblivion.rip/discord/lol.php?user=rip&email=testin@gmail.com&plan=lifetime&date=1536356112&ip=34.34.34.34';
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $DisApi);
    curl_setopt($ch, CURLOPT_REFERER, 'https://google.com');
    curl_setopt($ch, CURLOPT_HEADER, 1);
    curl_setopt($ch, CURLOPT_NOSIGNAL, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_TIMEOUT, 3);
    curl_exec($ch);
    curl_close($ch);
}
		
?>
<!-- page wrapper start -->
<div class="wrapper">
    <div class="container-fluid">

        <div class="page-title-box">
            <div class="row align-items-center">
        
                <div class="col-sm-12">
              <ol class="breadcrumb">
                  <li class="breadcrumb-item active">Oblivion / Purchase</li>
                </div>
            </div>
        </div>
        <!-- end row -->

        <div class="row">
            <?php
            $SQLGetPlans = $odb -> query("SELECT * FROM `plans` WHERE `private` = 0 ORDER BY `ID` ASC");
            while ($getInfo = $SQLGetPlans -> fetch(PDO::FETCH_ASSOC))
            {
              $id = $getInfo['ID'];
              $name = $getInfo['name'];
              $price = $getInfo['price'];
              $length = $getInfo['length'];
              $unit = $getInfo['unit'];
              $concurrents = $getInfo['concurrents'];
              $mbt = $getInfo['mbt'];
              $network = $getInfo['vip'];
              $api = $getInfo['api'];
              $totalservers = $getInfo['totalservers'];
                          
              if($network == "0")
              {
                $network = '<b class="text-primary"><i class="fa fa-feed text-warning"></i> Normal</b>';
                $colorx = 'bg-info';
                
              }elseif($network == "1")
              {
                $network = '<span class="text-danger font-w700"></i> VIP <i class="si si-fire text-warning"></i></span>';
                $colorx = 'bg-warning';
              }
              if($api == "0")
              {
                $api = '<span class="text-success font-w700"></i> No <i class="fa fa-bolt text-secondary"></i></span>';
              }elseif($api == "1")
              {
                $api = '<span class="text-primary font-w700"></i> Yes <i class="si si-fire text-success"></i></span>';
              }
            ?>
            <div class="col-xl-3 col-md-6">
                <div class="card pricing-box">
                    <div class="card-body">
                        <div class="mb-4 pt-3 pb-3">
                            <div class="pricing-icon float-left">
                                <i class="ion ion-ios-airplane"></i>
                            </div>
                            <div class="text-right">
                                <h5 class="mt-0"><?=$name?></h5>
                            </div>
                        </div>
                        <div class="pricing-features mb-4">
                            <p><i class="mdi mdi-check text-primary mr-2"></i> Concurrents: <?=$concurrents?></p>
                            <p><i class="mdi mdi-check text-primary mr-2"></i> Seconds: <?=$mbt?></p>
                            <p><i class="mdi mdi-check text-primary mr-2"></i> Network: <?=$network?></p>
                            <p><i class="mdi mdi-check text-primary mr-2"></i> Api Access: <?=$api?></p>
                            <p><i class="mdi mdi-check text-primary mr-2"></i> Total Servers: <?=$totalservers?></p>
                        </div>
                        <div class="text-center pt-3 pb-3">
                            <h2><sup><small>$</small></sup><?=$price?>/<span class="font-16"><?=$length.' '.$unit?></span></h2>
                        </div>
                        <div class="mt-4">
                            <a href="invoice.php?id=<?=$id?>" class="btn btn-primary btn-block waves-effect waves-light">Buy now!</a>
                        </div>
                    </div>
                </div>
            </div>
           <?php } ?>
            
        </div>
        <!-- end row -->
        
    </div>
    <!-- end container-fluid -->

</div>
<!-- page wrapper end -->

<?php include('footer.php'); ?>
      