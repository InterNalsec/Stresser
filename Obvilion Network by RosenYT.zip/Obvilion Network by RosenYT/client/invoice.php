<?php
    session_start();
    ${$pvgehdjvpcjk} = "Invoice";
    require_once "header.php";
    $qxfmilfxckq = "network";
    if (isset($_GET["id"])) {
        $id      = (int) $_GET["id"];
        $plansql = $odb->prepare("SELECT * FROM `plans` WHERE `ID` = :id");
        $plansql->execute(array(
            ":id" => $id
        ));
        $row = $plansql->fetch();
        if ($row === NULL) {
            die("Plan not found");
        }
    } else {
        header("Location: purchase.php");
        die("Invalid TIcket ID");
    }
    $GetInfo  = $odb->query("SELECT * FROM `users` WHERE `username`= '" . $_SESSION["username"] . "'");
    $userInfo = $GetInfo->fetch(PDO::FETCH_ASSOC);
    $SQL      = $odb->prepare("SELECT COUNT(*),`planID` FROM `payments` WHERE `invoiceID` = :invid AND `status` != '2'");
    $SQL->execute(array(
        ":invid" => htmlentities($_GET["invoice"])
    ));
    $rowPlani = $SQL->fetch(PDO::FETCH_ASSOC);
    if (empty($_GET["invoice"]) || $rowPlani["COUNT(*)"] == "0") {
        $gwfytj           = "fpqtnrr";
        $epneywwl         = "cypwrka";
        $cypwrka          = "GetPlanInfo";
        $rand             = rand(1111111, 9999999);
        ${$gwfytj}        = "planInfo";
        $SQLCheckRegister = $odb->prepare("INSERT INTO `payments`(`ID`, `IP`, `planID`, `invoiceID`, `status`, `username`, `date`) VALUES (NULL, :IP, :planID,:invoiceID,'0',:username,UNIX_TIMESTAMP(NOW()))");
        $SQLCheckRegister->execute(array(
            ":IP" => $user->realIP(),
            ":planID" => htmlentities($_GET["id"]),
            ":invoiceID" => $rand,
            ":username" => $_SESSION["username"]
        ));
        ${${$epneywwl}} = $odb->query("SELECT *,COUNT(*) FROM `plans` WHERE `id`= '" . htmlentities($_GET["id"]) . "'");
        $planInfo       = $GetPlanInfo->fetch(PDO::FETCH_ASSOC);
        if (${$fpqtnrr}["COUNT(*)"] == "0") {
        }
    } else {
        $rand        = htmlentities($_GET["invoice"]);
        $GetPlanInfo = $odb->query("SELECT *,COUNT(*) FROM `plans` WHERE `id`= '" . htmlentities($rowPlani["planID"]) . "'");
        $planInfo    = $GetPlanInfo->fetch(PDO::FETCH_ASSOC);
    }
    $network = $planInfo["vip"];
    if (${$qxfmilfxckq} == 0) {
        $network = "Normal Network";
    } else {
        $network = "ViP Network";
    }
    $api = $planInfo["api"];
    if ($api == 0) {
        $api = "No";
    } else {
        $api = "Yes";
    }
    $SQL = $odb->prepare("SELECT * FROM `users` WHERE `username` = :usuario");
    $SQL->execute(array(
        ":usuario" => $_SESSION["username"]
    ));
    $balancex = $SQL->fetch();
    $balance  = $balancex["balance"];
    if (isset($_POST["buy"])) {
        if (number_format((float) $balance, 2, ".", "") >= number_format((float) $row["price"], 2, ".", "")) {
            $getPlanInfo = $odb->prepare("SELECT `unit`,`length`,`name` FROM `plans` WHERE `ID` = :plan");
            $getPlanInfo->execute(array(
                ":plan" => $id
            ));
            $kbdsbtqdjg       = "bhjhxmqnxn";
            $plan             = $getPlanInfo->fetch(PDO::FETCH_ASSOC);
            $unit             = $plan["unit"];
            $bhjhxmqnxn       = "length";
            ${${$kbdsbtqdjg}} = $plan["length"];
            $name             = $plan["name"];
            $newExpire        = strtotime("+{$length} {$unit}");
            $updateSQL        = $odb->prepare("UPDATE `users` SET `expire` = :expire, `membership` = :plan WHERE `id` = :id");
            $updateSQL->execute(array(
                ":expire" => $newExpire,
                ":plan" => $id,
                ":id" => $_SESSION["ID"]
            ));
            $balance   = number_format((float) $balance, 2, ".", "") - number_format((float) $row["price"], 2, ".", "");
            $updateSQL = $odb->prepare("UPDATE `users` SET `balance` = :balance WHERE `id` = :id");
            $updateSQL->execute(array(
                ":balance" => $balance,
                ":id" => $_SESSION["ID"]
            ));
            $SQLUpdate = $odb->prepare("UPDATE `payments` SET `status`= '2' WHERE `username` = :username AND `invoiceID` = :invid");
            $SQLUpdate->execute(array(
                ":username" => $_SESSION["username"],
                ":invid" => htmlentities($_GET["invoice"])
            ));
            echo "<script type=\"text/javascript\">";
            echo "setTimeout(function () { swal(\"success!\",\x22Y\x6f\x75\x20\x68\x61\x76\x65\x20\x6e\x6f\x77\x20\x74\x68e\x20\x70\x6c\x61\x6e\x2e\x22,\x22\x73\x75\x63\x63\x65\x73\x73\x22)\x3b";
            echo "}, 1000);</script>";
        } else {
            echo "<script type=\"text/javascript\">";
            echo "setTimeout(function () { swal(\"Error!\",\"You need more money to buy this plan.\",\"error\");";
            echo "}, 1000);</script>";
        }
    }
    if (isset($_POST["btc"])) {
        header("Location: order.php?id=" . htmlentities($_GET["id"]) . "");
        die();
    }
    if (isset($_POST["pp"])) {
        header("Location: paypal.php");
        die();
    }

?>
<div class="wrapper">
  <div class="container-fluid">
    <div class="page-title-box">
      <div class="row align-items-center">

          <div class="col-sm-12">
              <h4 class="page-title">Invoice</h4>
              
          </div>
      </div>
    </div>
    <div class="row">
                    <div class="col-12">
                        <div class="card m-b-20">
                            <div class="card-body">

                                <div class="row">
                                    <div class="col-12">
                                        <div class="invoice-title">
                                            <h4 class="float-right font-16"><strong>Order #</strong></h4>
                                            <h3 class="mt-0">
                                                
                                            </h3>
                                        </div>
                                        <hr>

                                        <div class="row">
                                            <div class="col-6 m-t-30">
                                                <address>
                                                    <strong>Username:</strong><br>
                                                    <?= $userInfo['username']; ?><br>
                                                    <strong>Email:</strong><br>
                                                    <?= $userInfo['email']; ?>
                                                    
                                                </address>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-12">
                                        <div>
                                            <div class="p-2">
                                                <h3 class="font-16"><strong>Order summary</strong></h3>
                                            </div>
                                            <div class="">
                                                <div class="table-responsive">
                                                    <table class="table">
                                                        <thead>
                                                        <tr>
                                                            <td><strong>#ID</strong></td>
                                                            <td><strong>Product</strong></td>
                                                            <td ><strong>Qnt</strong>
                                                            </td>
                                                            <td><strong>Unit</strong></td>
                                                            <td ><strong>Amount</strong></td>

                                                        </tr>
                                                        </thead>
                                                        <tbody>
                                                        <!-- foreach ($order->lineItems as $line) or some such thing here -->
                                                        <tr>
                                                            <td><?=$planInfo['name']?></td>

                                                            <td>
                                                            <?=$planInfo['name']?>
                                                            Max boot time:<bb class="text-primary"> <?php echo $planInfo['mbt']; ?></bb>, 
                                                            Concurrents:<bb class="text-primary"> <?php echo $planInfo['concurrents']; ?> </bb>,
                                                            Network:<bb class="text-danger"> <?php echo $network; ?> </bb>,
                                                            Length:<bb class="text-warning"> <?php echo $planInfo['length']; ?> <?php echo $planInfo['unit']; ?></bb>,
                                                            Api Access:<bb class="text-info"> <?php echo $api; ?> </bb>
                                                            </td>
                                                            <td >
                                                                <span class="badge badge-pill badge-primary">1</span>
                                                            </td>
                                                            <td >$<?= $planInfo['price']?></td>
                                                            <td >$<?= $planInfo['price']?></td>
                                                        </tr>
                                                        
                                                        <tr>
                                                            <td class="thick-line"></td>
                                                            <td class="thick-line"></td>
                                                            <td class="thick-line text-center">
                                                                <strong>Subtotal</strong></td>
                                                            <td class="thick-line text-right">$<?= $planInfo['price']?></td>
                                                        </tr>
                                                        <tr>
                                                            <td class="no-line"></td>
                                                            <td class="no-line"></td>
                                                            <td class="no-line text-center">
                                                                <strong>Discount</strong></td>
                                                            <td class="no-line text-right">0%</td>
                                                        </tr>
                                                        <tr>
                                                            <td class="no-line"></td>
                                                            <td class="no-line"></td>
                                                            <td class="no-line text-center">
                                                                <strong>Total Due</strong></td>
                                                            <td class="no-line text-right"><h4 class="m-0">$<?= $planInfo['price']?></h4></td>
                                                        </tr>
                                                        </tbody>
                                                    </table>
                                                </div>

                                                <div class="d-print-none">
                                                    <div class="float-right">
                                                        <form method="POST">
<center>
    <a href="javascript:window.print()" class="btn btn-success waves-effect waves-light"><i class="fa fa-print"></i></a>



</center>
   </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div> <!-- end row -->

                            </div>
                        </div>
                    </div> <!-- end col -->
                </div>
  </div>
</div>

<?php include('footer.php'); ?>
      