<?php 

 // RiPx is the best ;)
 // if you leak this source you are dead nigga
 
session_start();
$page = "Team";
include 'header.php';
    $runningrip = $odb->query("SELECT COUNT(*) FROM `logs` WHERE `time` + `date` > UNIX_TIMESTAMP() AND `stopped` = 0")->fetchColumn(0);
	$slotsx = $odb->query("SELECT COUNT(*) FROM `api` WHERE `slots`")->fetchColumn(0);
	$load    = round($runningrip / $slotsx * 100, 2);	
	
	    if (!($user->isVerified($odb)))
        {
        header('location: verifyuser.php');
        die();
        }
		
?>
<main id="main-container" style="min-height: 843px;">
<div class="content">
    <div class="my-50 text-center">
        <h2 class="font-w700 text-white mb-10">Buy/Sell</h2>
        <h3 class="h5 text-muted mb-0">Bitcoin (BTC)</h3>
    </div>
    <div class="row justify-content-center text-center">
        <div class="col-lg-6 offset-lg-3">
            <div class="block block-fx-shadow">
          
                <div class="block-content tab-content">
                    <div class="tab-pane active" id="crypto-buy">
                        <form action="be_pages_crypto_buy_sell.php" method="post" onsubmit="return false;">
                            <div class="form-group row">
                                <label class="col-12" for="crypto-buy-from">Buy From</label>
                                <div class="col-12">
                                    <select class="form-control form-control-lg" id="crypto-buy-from" name="crypto-buy-from" size="3">
                                        <option value="paypal">PAYPAL - EUR €</option>
                                        <option value="btc">BITCOIN - USD $</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-12" for="crypto-buy-to">Deposit To</label>
                                <div class="col-12">
                                    <select class="form-control form-control-lg" id="crypto-buy-to" name="crypto-buy-to">
                                        <option value="5">5 - €</option>
										<option value="13">13 - €</option>
										<option value="20">20 - €</option>
										<option value="26">26 - €</option>
										<option value="50">50 - €</option>
										<option value="55">55 - €</option>
										<option value="70">70 - €</option>
										<option value="85">85 - €</option>
										<option value="100">100 - €</option>
										<option value="125">125 - €</option>										
                                    </select>
                                </div>
                            </div>
                 <hr>
						   <div class="form-group form-actions">
<div class="col-xs-8">
<label class="css-control css-control-success css-switch">
                                    <input type="checkbox" class="css-control-input" id="ecom-product-published" name="ecom-product-published" checked="" disabled>
                                    <span class="css-control-indicator"></span>
                                </label>
Accept <span class="badge badge-primary">T.O.S</span>
</div>
</div>
                            <div class="form-group row">
                                <div class="col-12">
                                    <button type="submit" class="btn btn-hero btn-lg btn-block btn-alt-primary">Buy Now!</button>
                                </div>
                            </div>
                        </form>
                    </div>
                   
                </div>
            </div>
        </div>
    </div>
</div>
    </main>

 <!-- END Page Container -->
<?php include('footer.php'); ?>
      