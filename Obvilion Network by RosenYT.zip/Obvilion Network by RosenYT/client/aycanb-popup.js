/**
 * --------------------------------------------------------------------
 * jQuery Uygulamas� "popup"
 * Aycan BULBUL, ab@aycan.net
 * Tarih 26 Temmuz 2010
 *
 *                      http://www.aycan.net/
 * * --------------------------------------------------------------------
 *  Kullanim klavuzu
 *          http://www.aycan.net/blog/jquery-ajax-javascript/jquery-popup-uygulamasi.html
 *
 */

$(document).ready(function(){
    //popup a�ma
    $('.kapsayiciSiyah').fadeTo('fast',0.60);
    setTimeout(function(){ $('.disKutu').fadeIn('slow'); }, 900);
    //esc ye bas�nca kapatma
    $(document).bind('keydown',function Kapat(e){
        if (e.keyCode == 27) {
            $('.disKutu').slideUp('slow');
            setTimeout(function(){ $('.kapsayiciSiyah').fadeOut('slow'); }, 900);
        }
    });
    //siyah ekrana t�klay�nca kapatma
    $('.kapsayiciSiyah').click(function(){
         $('.disKutu').slideUp('slow');
         setTimeout(function(){ $('.kapsayiciSiyah').fadeOut('slow'); }, 900);
    })
    //resime t�klay�nca kapatma
    $('.kutulariKapat').click(function(){
         $('.disKutu').slideUp('slow');
         setTimeout(function(){ $('.kapsayiciSiyah').fadeOut('slow'); }, 900);
    })

    //yukseklikleri e�itleme
    var yukseklik = $('.disKutu').height();
    var ekranYukseklik = screen.height;
    var yukseklikYari = yukseklik/2;
        if(ekranYukseklik > yukseklik){
            var yukseklikAyarla = (ekranYukseklik - yukseklik)/3;
            $('.disKutu').css({
                'margin-top': yukseklikAyarla
            });
        }else{
             $('.disKutu').css({
                'margin-top': '20px',
                'margin-bottom': '20px'
            });
            }
    });